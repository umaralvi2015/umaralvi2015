#..................................................
#........Name: Ummer Shakeel.......................
#........Roll #: 20-MS-DS-18.......................
#........SUBJECT: SOCIAL NETWORK ANAYLSIS..........
#........TEACHER: DR. JAVED IQBAL..................
#........SEMESTER PROJECT..........................

#..................................................
#...........Text Mining............................
#..................................................

# set working directory 
setwd("C:/Users/Umar Alvi/Desktop/Project SNA")
# get working directory
print(getwd())
# include libraries
library(syuzhet)
library(ggplot2)
library(tm)
library(wordcloud)
# load and choose dataset file 
reviews=read.csv(file.choose() , header = T)
# structure of dataset
str(reviews)
# craete corpus
corpus <- iconv(reviews$reviews)
corpus <- Corpus(VectorSource(corpus))
inspect(corpus[1:20])
# clean corpus
corpus <- tm_map(corpus, tolower)
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeNumbers)
corpus <- tm_map(corpus, removeWords , stopwords("english") )
corpus <- tm_map(corpus, stripWhitespace)
reviews_final <- corpus
inspect(reviews_final[1:10])
# Lematization
# install.packages('textstem')
library(textstem)
reviews_final<- lemmatize_words(reviews_final, dictionary = lexicon::hash_lemmas)
# create term document
tdm <- TermDocumentMatrix(reviews_final)
tdm <- as.matrix(tdm)
tdm[1:10, 1:5]
# barplot of words
b <- rowSums(tdm)
b <- subset(b, b>=5)
barplot(b, las=2, col = "blue" )
# create word cloud
w <- sort(rowSums(tdm), decreasing = T)
set.seed(1234)
wordcloud(words = names(w),
          freq = w,
          max.words = 100,
          random.order = T,
          min.freq = 5,
          colors = brewer.pal(25,"Dark2"),
          scale = c(3,0.3))
#.................................................
#...........Sentimental Analysis..................
#.................................................
sentiment_data <- iconv(reviews$reviews)
sentiment=get_nrc_sentiment(sentiment_data)
print(sentiment)
# calculate review wise score
sentiment$score<- sentiment$positive - sentiment$negative
print(sentiment)
# total sentimental score
text=cbind(sentiment_data,sentiment)
TotalSentiment=data.frame(colSums(text[,c(2:11)]))
TotalSentiment
names(TotalSentiment)="count"
TotalSentiment
names(TotalSentiment)="count"
TotalSentiment=cbind("sentiment"=rownames(TotalSentiment), TotalSentiment)
rownames(TotalSentiment)=NULL
ggplot(data=TotalSentiment,aes(x=sentiment,y=count))+
  geom_bar(aes(fill=sentiment),stat ="identity")+
  theme(legend.position="none")+
  xlab("sentiment")+
  ylab("total count")+
  ggtitle("Total Sentimental Score")+
  ggeasy::easy_center_title() # to run this line first download pkg "remotes::install_github("jonocarroll/ggeasy")"

#.................................THE END........................................









